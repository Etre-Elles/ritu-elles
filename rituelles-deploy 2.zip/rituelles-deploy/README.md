# Ritu'Elles — Déploiement sur static.app

## Fichiers inclus

- `index.html` — page principale
- `app.jsx` — l'application complète (250 affirmations, 12 catégories)
- `sw.js` — service worker pour les notifications PWA
- `manifest.json` — configuration PWA (icône, nom, couleurs)

## À ajouter avant de déployer

Tu dois ajouter manuellement ces deux fichiers (générés avec ChatGPT) :

- `icon-192.png` — icône 192×192px
- `icon-512.png` — icône 512×512px

## Déploiement sur static.app

1. Va sur https://static.app
2. Crée un nouveau site
3. Glisse-dépose TOUS les fichiers (index.html, app.jsx, sw.js, manifest.json, icon-192.png, icon-512.png)
4. Ton site est en ligne

## Installer l'app sur iPhone

1. Ouvre l'URL dans Safari
2. Appuie sur le bouton Partager ↑
3. Sélectionne « Sur l'écran d'accueil »
4. Nomme l'app « Ritu'Elles » et appuie sur Ajouter

## Installer l'app sur Android

1. Ouvre l'URL dans Chrome
2. Appuie sur ⋮ puis « Ajouter à l'écran d'accueil »
