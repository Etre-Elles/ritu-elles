self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => clients.claim());

self.addEventListener('message', e => {
  if (e.data?.type === 'SCHEDULE_NOTIF') {
    setTimeout(() => {
      self.registration.showNotification("Ritu'Elles ✦", {
        body: e.data.body || "Ton moment pour toi t'attend.",
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        vibrate: [200, 100, 200],
      });
    }, e.data.delay);
  }
});
