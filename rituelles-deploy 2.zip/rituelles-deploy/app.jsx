const { useState, useEffect, useCallback } = React;

/* ─── TOKENS ─── */
const PIVOINE   = "#C8637A";
const PRUNE     = "#44305A";
const NUIT      = "#1E1028";
const ROSE_SAT  = "#C97A8E";
const VIEUX     = "#E8D2E0";
const AUBE      = "#F9F6FD";
const LILAS_L   = "#C8B0E8";
const GOLD      = "#D4A843";
const GOLD2     = "#E8C06A";
const DARK_PAGE  = "#2D1B45";
const DARK_PAGE2 = "#3D2656";
const TEXT3 = "#6b6575";
const TEXT4 = "#7a7485";
const TEXT5 = "#9b95a5";

/* ─── UTILS ─── */
const pickRandom = (pool, n) => [...pool].sort(() => Math.random() - 0.5).slice(0, Math.min(n, pool.length));
async function registerSW() {
  if ("serviceWorker" in navigator) { try { await navigator.serviceWorker.register("/sw.js"); } catch {} }
}
function scheduleNotif(timeStr) {
  if (!timeStr || !("serviceWorker" in navigator)) return;
  navigator.serviceWorker.ready.then(reg => {
    const [h, m] = timeStr.split(":").map(Number);
    const now = new Date(), target = new Date();
    target.setHours(h, m, 0, 0);
    if (target <= now) target.setDate(target.getDate() + 1);
    const msgs = ["Ton rituel du jour t'attend. ✦","Un moment rien que pour toi. ✦","Commence avec une intention. ✦","Prends un instant pour toi. ✦"];
    reg.active?.postMessage({ type:"SCHEDULE_NOTIF", delay:target-now, body:msgs[Math.floor(Math.random()*msgs.length)] });
  }).catch(()=>{});
}

/* ─── CATÉGORIES ─── */
const CATEGORIES = [
  { id:"confiance",     label:"Confiance en soi" },
  { id:"temps",         label:"Gestion du temps" },
  { id:"equilibre",     label:"Équilibre vie pro/perso" },
  { id:"resilience",    label:"Résilience & stress" },
  { id:"motivation",    label:"Motivation & productivité" },
  { id:"sante",         label:"Santé & bien-être" },
  { id:"competences",   label:"Développement perso" },
  { id:"finances",      label:"Autonomie financière" },
  { id:"relations",     label:"Relations & communication" },
  { id:"impact",        label:"Impact & contribution" },
  { id:"manifestation", label:"Manifestation" },
  { id:"legitimite",    label:"Légitimité & leadership" },
];

/* ─── AFFIRMATIONS [affirmation, message] ─── */
const RAW = {
  confiance:[
    ["Je suis capable et digne de réussir.","Tu n'as pas besoin de mériter ta place, c'est déjà la tienne."],
    ["Je crois en moi et en mes capacités.","Aujourd'hui, fais une chose que tu repousses par peur de ne pas être à la hauteur."],
    ["Je mérite le succès et le bonheur.","À quoi ressemblerait ta vie si tu te permettais vraiment de réussir ?"],
    ["Chaque jour, je deviens plus confiante.","La confiance ne s'installe pas d'un coup. Chaque petit pas compte autant que les grands."],
    ["Je m'accepte telle que je suis.","Qu'est-ce que tu t'autoriserais à faire si tu cessais de te juger ?"],
    ["Mes opinions et mes idées sont importantes.","Partage une idée aujourd'hui que tu as gardée pour toi par peur du regard des autres."],
    ["J'ai le pouvoir de changer ma vie.","Tu n'es pas spectatrice de ta vie, tu en es l'autrice."],
    ["Je suis fière de mes réalisations.","Prends 5 minutes pour écrire trois choses que tu as accomplies cette semaine, même les plus petites."],
    ["Je surmonte mes peurs avec courage.","Quelle peur, si tu la surmontais, changerait tout pour toi ?"],
    ["Je suis une personne unique et spéciale.","Ce qui te distingue des autres n'est pas un défaut, c'est ta signature."],
    ["Je me fais confiance pour prendre les bonnes décisions.","Face à une décision qui traîne, écoute ton instinct plutôt que tes doutes et avance."],
    ["J'accueille les compliments avec gratitude.","Pourquoi est-il si difficile d'accepter ce qu'on dit de bien de toi ?"],
    ["Je suis assez compétente pour atteindre mes objectifs.","Tu as déjà tout ce qu'il faut pour commencer. Le reste s'apprend en chemin."],
    ["J'ai le droit de me tromper et d'apprendre de mes erreurs.","Reviens sur une erreur récente et identifie une seule chose qu'elle t'a appris sur toi."],
    ["Je suis digne d'amour et de respect.","Est-ce que tu te traites avec autant de douceur que tu traiterais une amie ?"],
    ["Je suis en train de devenir la meilleure version de moi-même.","Tu n'as pas à être parfaite aujourd'hui. Tu es exactement où tu dois être."],
    ["Je crois en mes capacités à relever des défis.","Nomme un défi qui t'attend et écris la première étape concrète pour l'affronter."],
    ["Mon potentiel est illimité.","Qu'est-ce que tu arrêterais de faire si tu savais que tu ne peux pas échouer ?"],
    ["J'apprends et je grandis chaque jour.","Évoluer c'est parfois inconfortable et c'est exactement le signe que tu avances."],
    ["Je m'autorise à briller sans m'en excuser.","Aujourd'hui, fais quelque chose de visible sans minimiser ce que tu fais ou qui tu es."],
  ],
  temps:[
    ["Je gère mon temps efficacement et avec sagesse.","Ce soir, prépare ta liste des trois choses essentielles à accomplir demain. Rien d'autre."],
    ["Je priorise mes tâches pour maximiser ma productivité.","Sur tout ce que tu as à faire aujourd'hui, qu'est-ce qui compte vraiment ?"],
    ["J'accomplis mes tâches avec efficacité.","Tu n'as pas à tout faire parfaitement. Bien fait vaut mieux que parfait jamais terminé."],
    ["Je planifie mes journées pour être productive.","Bloque un créneau dans ton agenda aujourd'hui pour une tâche que tu repousses depuis trop longtemps."],
    ["Je termine ce que je commence.","Qu'est-ce qui te fait abandonner en cours de route, et qu'est-ce que ça te coûte vraiment ?"],
    ["Je suis organisée et méthodique.","L'organisation n'est pas une contrainte, c'est ce qui te libère pour ce qui compte."],
    ["J'utilise mon temps pour les choses qui comptent vraiment.","Si tu regardais ta semaine honnêtement, ton temps reflète-t-il tes vraies priorités ?"],
    ["Je sais dire non aux distractions.","Identifie la distraction qui te vole le plus de temps et supprime-la de ta matinée pendant une semaine."],
    ["Je respecte mes délais.","Tenir ses engagements envers soi-même, c'est la première forme de respect de soi."],
    ["Je suis responsable de mon emploi du temps.","Qui décide vraiment de comment tu passes tes journées, toi ou les urgences des autres ?"],
    ["Je fais des pauses pour rester productive.","Pose ton téléphone, ferme tes onglets et accorde-toi dix minutes de vrai repos maintenant."],
    ["Je délègue quand c'est nécessaire.","Tout faire seule n'est pas une force. Savoir déléguer, c'est choisir de te concentrer sur l'essentiel."],
    ["Je fais de chaque minute une opportunité.","Comment voudrais-tu te souvenir de cette journée ce soir au moment de t'endormir ?"],
    ["Je sais quand prendre des pauses pour rester en forme.","Programme une vraie pause aujourd'hui, pas entre deux mails, une pause où tu décroches complètement."],
    ["Je me concentre sur les tâches importantes.","L'urgent crie fort mais l'important chuchote. Apprends à écouter ce qui chuchote."],
    ["Je sais équilibrer travail et repos.","Est-ce que tu te permets de te reposer sans culpabilité, ou le repos doit-il encore se mériter ?"],
    ["Je suis ponctuelle et fiable.","Être là à l'heure, pour les autres comme pour soi-même, c'est une façon de dire que tu te respectes."],
    ["Je fais des choix judicieux pour mon emploi du temps.","Avant d'accepter ta prochaine demande, demande-toi d'abord si elle te rapproche de ce qui compte pour toi."],
    ["Je sais prioriser mes activités essentielles.","Si tu ne pouvais garder que trois engagements cette semaine, lesquels choisirais-tu ?"],
    ["Je choisis mes priorités avec lucidité et sérénité.","Choisir c'est renoncer, et renoncer c'est aussi se libérer. Tu as cette sagesse en toi."],
  ],
  equilibre:[
    ["Je trouve un équilibre harmonieux entre ma vie professionnelle et personnelle.","Est-ce que ta vie ressemble à ce que tu veux vraiment, ou à ce qu'on attend de toi ?"],
    ["Je mérite de prendre du temps pour moi chaque jour.","Prendre soin de toi n'est pas un luxe. C'est ce qui te permet de donner le meilleur de toi-même."],
    ["Je respecte mes limites pour maintenir mon bien-être.","Aujourd'hui, dis non à une demande qui empiète sur ton temps personnel. Sans explication."],
    ["Je prends soin de moi et de mes besoins personnels.","Qu'est-ce que tu t'offres chaque jour pour prendre soin de toi, au-delà des obligations ?"],
    ["Je m'accorde du temps pour me détendre et me reposer.","Le repos n'est pas une récompense. C'est une nécessité, et tu y as droit maintenant."],
    ["Je suis présente et engagée dans chaque aspect de ma vie.","Choisis un moment aujourd'hui pour être pleinement là, téléphone posé, sans penser à autre chose."],
    ["Je gère mes priorités avec équilibre et discernement.","Qu'est-ce que tu sacrifies en ce moment sans vraiment l'avoir décidé consciemment ?"],
    ["Je suis en paix avec mon emploi du temps.","La paix ne vient pas d'avoir moins à faire. Elle vient de savoir pourquoi tu fais ce que tu fais."],
    ["Je me détends sans culpabilité.","D'où vient cette voix qui te dit que tu n'as pas encore assez mérité de souffler ?"],
    ["J'équilibre mon travail avec des moments de plaisir.","Planifie quelque chose qui te fait plaisir cette semaine et traite ce rendez-vous comme un rendez-vous professionnel."],
    ["Je profite pleinement de chaque instant.","La vie ne se passe pas après la to-do list. Elle se passe maintenant, dans cet instant."],
    ["Je suis attentive à mes besoins émotionnels.","Comment tu te sens vraiment en ce moment, au-delà de « ça va » ?"],
    ["Je respecte mon temps personnel et professionnel.","Définis une heure à partir de laquelle tu ne regardes plus tes mails professionnels. Et tiens-toi y."],
    ["Je prends du temps pour les choses qui me rendent heureuse.","Ce qui te rend heureuse mérite une place dans ton agenda, pas juste dans tes rêves."],
    ["Je prends soin de mon bien-être global.","Si tu évaluais ton bien-être aujourd'hui sur 10, quel score donnerais-tu et pourquoi ?"],
    ["Je suis en harmonie avec mes responsabilités personnelles et professionnelles.","Identifie une responsabilité qui t'épuise et réfléchis à comment tu pourrais l'alléger ou la partager."],
    ["Je respecte mon temps libre autant que mon temps de travail.","Ton temps libre n'a pas à se justifier. Il t'appartient."],
    ["Je m'autorise à prendre soin de moi.","Quelle permission te manque-t-il pour vraiment prendre soin de toi sans te sentir égoïste ?"],
    ["Je trouve du plaisir dans chaque aspect de ma vie.","Trouve une tâche que tu fais en ce moment sans plaisir et cherche une façon de la rendre plus légère."],
    ["Je crée une vie qui me ressemble vraiment.","Ta vie n'a pas à ressembler à celle des autres. Elle doit juste te ressembler, à toi."],
  ],
  resilience:[
    ["Je suis résiliente et capable de surmonter les défis.","Tu as déjà traversé des choses difficiles. Rappelle-toi d'où tu viens avant de douter d'où tu vas."],
    ["Je reste calme et sereine même dans les situations difficiles.","Quand tu sens la tension monter, pose une main sur ton cœur et respire profondément trois fois avant de réagir."],
    ["Je transforme le stress en énergie positive.","Qu'est-ce que ce stress tente de te dire sur ce qui compte vraiment pour toi ?"],
    ["Je suis maîtresse de mes émotions.","Ressentir intensément n'est pas une faiblesse. C'est ce qui te rend humaine et vivante."],
    ["Je rebondis rapidement après les échecs.","Pense à un échec récent et écris une seule chose qu'il t'a permis de comprendre sur toi."],
    ["Je trouve la paix intérieure en toute situation.","À quoi ressemble la paix pour toi, concrètement, dans ton quotidien ?"],
    ["Je prends des pauses pour me ressourcer.","Offre-toi vingt minutes aujourd'hui sans téléphone, sans écran, sans rien à produire."],
    ["Je respire profondément pour calmer mon esprit.","Ton souffle est toujours là, disponible, gratuit. C'est ton premier outil de retour au calme."],
    ["Je gère le stress avec grâce et efficacité.","Qu'est-ce qui t'aide vraiment à revenir à toi quand tout s'emballe autour de toi ?"],
    ["Je reste positive même dans les situations difficiles.","Rester positive ne veut pas dire nier ce qui est dur. Ça veut dire choisir de ne pas s'y perdre."],
    ["Je suis calme et sereine en toute circonstance.","Identifie ce qui déclenche ton stress le plus souvent et prépare une réponse consciente pour la prochaine fois."],
    ["Je reste optimiste face à l'adversité.","Quelle épreuve passée t'a finalement rendue plus forte que tu ne le pensais ?"],
    ["Je gère mon stress avec des techniques de relaxation.","Essaie ce soir une technique que tu n'as pas encore testée, méditation, étirements, écriture libre."],
    ["Je suis forte et capable de surmonter les obstacles.","La force ne signifie pas ne jamais avoir peur. Elle signifie avancer malgré la peur."],
    ["Je reste flexible et adaptable aux changements.","Face à un changement qui t'inquiète, qu'est-ce qui t'empêche de lui faire confiance ?"],
    ["Je trouve des solutions positives à mes problèmes.","Face à un problème qui tourne en boucle dans ta tête, écris trois pistes possibles, même imparfaites."],
    ["Je fais face aux défis avec confiance.","Le défi devant toi est peut-être exactement ce dont tu avais besoin pour découvrir quelque chose de nouveau sur toi."],
    ["Je reste calme et centrée.","Quand tout va vite autour de toi, à quoi ou à qui tu te raccroches pour rester toi-même ?"],
    ["Je fais preuve de résilience face aux défis.","Pense à une situation difficile en cours et identifie une seule chose sur laquelle tu as encore le contrôle."],
    ["Chaque épreuve me révèle une force que j'ignorais.","Ce que tu traverses en ce moment te construit d'une façon que tu ne peux pas encore voir."],
  ],
  motivation:[
    ["Je suis motivée et accomplis mes objectifs avec succès.","Écris ton objectif principal du moment sur un papier et pose-le là où tu le verras plusieurs fois aujourd'hui."],
    ["Chaque jour, je fais des progrès vers mes rêves.","Un tout petit pas dans la bonne direction vaut mille grands pas dans la mauvaise."],
    ["Je suis concentrée et déterminée dans mes projets.","Qu'est-ce qui te distrait le plus souvent de ce qui compte vraiment pour toi ?"],
    ["Je persévère même face aux obstacles.","La persévérance n'est pas l'absence de doute. C'est continuer malgré lui."],
    ["Je me fixe des objectifs clairs et atteignables.","Prends un grand objectif qui t'intimide et découpe-le en trois étapes concrètes pour cette semaine."],
    ["Je suis disciplinée dans mon travail.","La discipline te pèse ou te libère ? D'où vient ta relation à l'effort ?"],
    ["Je suis dynamique et pleine d'énergie.","Commence ta journée par cinq minutes de mouvement, même léger, avant de regarder ton téléphone."],
    ["Je trouve des solutions créatives à mes défis.","Quand une porte se ferme, tu as cette capacité de trouver une fenêtre. Fais-toi confiance."],
    ["Je suis engagée et passionnée par mon travail.","Est-ce que ce sur quoi tu travailles en ce moment te donne de l'élan ou te vide de ton énergie ?"],
    ["Je suis inspirée et motivée chaque jour.","Qu'est-ce qui t'inspirait quand tu étais enfant ? Trouve un lien, même petit, entre ça et ce que tu fais aujourd'hui."],
    ["Je suis focalisée sur mes priorités.","Te concentrer sur l'essentiel, c'est déjà un acte de courage dans un monde qui te tire dans tous les sens."],
    ["Je suis persévérante et déterminée.","Quel projet as-tu abandonné trop tôt et que tu regrettes encore un peu ?"],
    ["Je suis enthousiaste à l'idée de nouveaux projets.","Si la peur et le manque de temps n'existaient pas, quel projet lancerais-tu demain ?"],
    ["Je garde une attitude positive chaque jour.","La positivité n'est pas naïve. C'est un choix conscient que tu fais pour toi, pas pour les autres."],
    ["Je suis prête à relever de nouveaux défis.","Quel défi tu t'interdis d'envisager parce que tu penses ne pas être prête ?"],
    ["Je transforme les obstacles en opportunités.","Prends un obstacle actuel et retourne-le : qu'est-ce qu'il te force à apprendre ou à développer ?"],
    ["Je suis toujours en train de progresser.","Le progrès est rarement visible jour après jour. C'est en regardant en arrière qu'on réalise le chemin parcouru."],
    ["Je suis déterminée à réussir.","Qu'est-ce que réussir signifie vraiment pour toi, selon tes propres critères ?"],
    ["Je suis passionnée par ce que je fais.","Fais aujourd'hui une chose en lien avec ta passion, même si ça prend seulement dix minutes."],
    ["Je commence, et le reste suit naturellement.","Tu n'as pas besoin d'être prête. Tu as juste besoin de commencer."],
  ],
  sante:[
    ["Je prends soin de ma santé physique et mentale.","Aujourd'hui, fais une chose bonne pour ton corps et une chose bonne pour ton esprit. Une seule de chaque."],
    ["Je mérite de me sentir bien dans mon corps et dans mon esprit.","Ton bien-être n'est pas une récompense que tu dois mériter. C'est un droit fondamental."],
    ["Je nourris mon corps avec des aliments sains et équilibrés.","Est-ce que tu manges pour te nourrir vraiment, ou souvent pour combler autre chose ?"],
    ["J'écoute mon corps et réponds à ses besoins.","Fais une pause maintenant. Ferme les yeux, scanne ton corps et donne-lui ce dont il a besoin."],
    ["Je pratique régulièrement une activité physique.","Bouger n'a pas à être une contrainte. Trouve ce qui te fait du bien et c'est suffisant."],
    ["Je dors suffisamment pour recharger mes batteries.","Est-ce que tu te permets de dormir suffisamment ou est-ce que la fatigue est devenue normale pour toi ?"],
    ["Je pratique la gratitude pour mon bien-être quotidien.","Écris ce soir trois choses, même minuscules, pour lesquelles tu es reconnaissante aujourd'hui."],
    ["Je fais de l'exercice pour rester en forme.","Ton corps fait tellement pour toi chaque jour. Prends soin de lui comme il prend soin de toi."],
    ["Je prends soin de mon esprit par la méditation.","Essaie cinq minutes de silence conscient aujourd'hui. Juste observer tes pensées sans les suivre."],
    ["Je prends du temps pour moi chaque jour.","Quel serait ton rituel idéal pour toi seule, si tu t'en donnais vraiment la permission ?"],
    ["Je bois suffisamment d'eau pour rester hydratée.","Les petits gestes de soin quotidiens sont des actes d'amour envers toi-même. Commence par un verre d'eau."],
    ["Je prends soin de ma santé mentale.","Comment évalues-tu ta santé mentale en ce moment, honnêtement ?"],
    ["Je mange équilibré pour nourrir mon corps.","Prépare ou commande aujourd'hui un repas qui te fait vraiment du bien, avec intention et plaisir."],
    ["Je pratique des activités qui me détendent.","Ce qui te détend n'a pas à être productif. Le plaisir pur a sa place dans ta vie."],
    ["Je prends soin de mon corps avec amour.","Quelle est la chose que ton corps te demande depuis longtemps et que tu n'as pas encore écoutée ?"],
    ["Je fais attention à ma posture et à ma respiration.","Redresse-toi maintenant, détends tes épaules et prends trois grandes respirations. Tu sentiras la différence."],
    ["Je maintiens une routine de bien-être quotidienne.","Une routine n'a pas à être parfaite pour être puissante. La régularité compte plus que la perfection."],
    ["Je m'accorde des moments de relaxation.","Quand as-tu ressenti pour la dernière fois un vrai relâchement, sans rien à faire ni à penser ?"],
    ["Je prends soin de mon esprit autant que de mon corps.","Consacre trente minutes aujourd'hui à quelque chose qui nourrit ton esprit, lire, créer, explorer."],
    ["Mon corps mérite les mêmes soins que j'offre aux autres.","Tu prends soin de tout le monde autour de toi. Il est temps de te mettre sur cette liste."],
  ],
  competences:[
    ["J'apprends et je grandis chaque jour.","Chaque jour t'apporte quelque chose de nouveau si tu te donnes la peine de le remarquer."],
    ["Je suis ouverte à de nouvelles opportunités d'apprentissage.","Qu'est-ce que tu refuses d'apprendre parce que tu penses que c'est trop tard ou pas pour toi ?"],
    ["Je développe mes compétences avec passion.","Identifie une compétence que tu veux développer et consacre-lui trente minutes cette semaine."],
    ["Je m'engage à apprendre de nouvelles choses.","La curiosité est l'une de tes forces les plus précieuses. Garde-la vivante."],
    ["Je suis curieuse et cherche à en savoir plus chaque jour.","Lis, écoute ou regarde quelque chose aujourd'hui sur un sujet que tu ne connais pas encore."],
    ["J'améliore constamment mes connaissances.","Dans quel domaine de ta vie as-tu arrêté d'apprendre et pourquoi ?"],
    ["Je suis engagée dans mon développement personnel.","Investir en toi est le meilleur investissement que tu puisses faire. Tu en vaux chaque effort."],
    ["J'aime apprendre et m'améliorer chaque jour.","Partage quelque chose que tu as appris récemment avec quelqu'un de ton entourage."],
    ["J'acquiers de nouvelles compétences avec joie.","Qu'est-ce que tu aimais apprendre enfant qui te manque aujourd'hui ?"],
    ["Je cherche à exceller dans tout ce que je fais.","Exceller ne veut pas dire être parfaite. Ça veut dire donner le meilleur de toi-même, là où tu en es."],
    ["J'apprécie le processus d'apprentissage.","Est-ce que tu t'autorises à ne pas savoir, ou est-ce que l'inconfort de la nouveauté te stoppe ?"],
    ["Je mets en pratique ce que j'apprends.","Prends une chose apprise récemment et applique-la concrètement aujourd'hui, même de façon imparfaite."],
    ["Je me fixe des objectifs de développement clairs.","Savoir où tu veux aller te donne une direction. Et une direction, c'est déjà une forme de liberté."],
    ["Je suis déterminée à m'améliorer constamment.","Est-ce que tu cherches à t'améliorer pour toi ou pour répondre aux attentes des autres ?"],
    ["Je suis en quête de nouvelles connaissances.","Inscris-toi aujourd'hui à quelque chose qui t'attire depuis longtemps, formation, atelier, podcast, livre."],
    ["Je me consacre à mon développement personnel.","Travailler sur toi n'est pas égoïste. C'est ce qui te permet d'être pleinement là pour les autres."],
    ["J'embrasse les défis comme des opportunités de croissance.","Quel défi actuel cache peut-être une opportunité que tu n'as pas encore vue ?"],
    ["Je m'investis dans mon apprentissage continu.","Crée un espace dans ta semaine, même vingt minutes, dédié uniquement à ton développement."],
    ["Je suis en constante évolution.","Tu n'es pas la même qu'il y a un an. C'est une force, pas une instabilité."],
    ["Je grandis à mon rythme, et c'est suffisant.","Ton chemin n'a pas à ressembler à celui des autres. Ton rythme est le bon rythme pour toi."],
  ],
  finances:[
    ["Je suis financièrement indépendante et épanouie.","Qu'est-ce que l'indépendance financière changerait concrètement dans ta façon de vivre ?"],
    ["Je prends des décisions financières éclairées et responsables.","Prends dix minutes aujourd'hui pour regarder tes comptes avec lucidité, sans jugement."],
    ["J'épargne régulièrement pour assurer mon avenir.","Chaque euro mis de côté est un geste d'amour envers la version future de toi-même."],
    ["Je suis proactive dans la gestion de mes finances.","Qu'est-ce qui te retient de prendre tes finances vraiment en main ?"],
    ["Je vis dans l'abondance et la prospérité.","Note aujourd'hui trois formes d'abondance déjà présentes dans ta vie, pas forcément financières."],
    ["Je fais des choix financiers qui reflètent mes valeurs.","Ton argent suit tes priorités. Est-ce que tes dépenses racontent l'histoire que tu veux vivre ?"],
    ["Je gère mon argent avec sagesse et prudence.","Quelle relation as-tu héritée avec l'argent et est-ce que cette relation te sert encore ?"],
    ["J'investis dans des opportunités de croissance financière.","Renseigne-toi aujourd'hui sur une façon de faire travailler ton argent pour toi, même modestement."],
    ["Je vis dans la prospérité et l'abondance.","La prospérité commence dans l'esprit bien avant d'arriver sur le compte en banque."],
    ["Je crée des sources de revenus multiples.","Quelle compétence ou passion pourrais-tu transformer en source de revenus complémentaire ?"],
    ["Je suis capable de réaliser mes objectifs financiers.","Écris un objectif financier précis avec une date et la première étape concrète pour l'atteindre."],
    ["J'attire la prospérité dans ma vie.","Ce que tu crois mériter influence ce que tu oses viser. Tu mérites la prospérité."],
    ["Je suis en contrôle de ma situation financière.","Si tu devais noter ta sérénité financière sur 10 aujourd'hui, quel score donnerais-tu et pourquoi ?"],
    ["Je suis reconnaissante pour l'abondance que j'ai dans ma vie.","Fais la liste de tout ce que tu as aujourd'hui qui aurait semblé incroyable à ta version d'il y a cinq ans."],
    ["Je vis une vie financièrement stable et sécurisée.","La sécurité financière se construit pas à pas. Chaque décision sage compte."],
    ["Je suis capable de gérer mes finances avec succès.","Qu'est-ce qui t'empêche de te faire vraiment confiance sur le plan financier ?"],
    ["Je prends des décisions financières positives.","Avant ta prochaine dépense non essentielle, pose-toi une seule question : est-ce que ça me rapproche de mes objectifs ?"],
    ["Je gère efficacement mon budget.","Gérer son budget n'est pas une punition. C'est reprendre le pouvoir sur sa vie."],
    ["Je vis une vie financièrement épanouissante.","À quoi ressemblerait une vie financièrement épanouissante pour toi, dans les détails concrets ?"],
    ["Je construis chaque jour une relation saine avec l'argent.","Identifie une croyance négative que tu as sur l'argent et remplace-la par une pensée plus utile."],
  ],
  relations:[
    ["Je suis entourée de relations positives et bienveillantes.","Les personnes qui t'entourent te donnent-elles de l'énergie ou t'en prennent-elles ?"],
    ["Je communique avec clarté et empathie.","Dis aujourd'hui à quelqu'un quelque chose que tu penses souvent mais que tu gardes pour toi."],
    ["Je respecte et j'écoute les autres.","Écouter vraiment, c'est l'un des plus beaux cadeaux que tu puisses offrir à quelqu'un."],
    ["J'entretiens des relations saines et épanouissantes.","Quelle relation dans ta vie gagnerait à ce que tu y investisses un peu plus de présence ?"],
    ["Je suis authentique dans mes interactions.","Dans ta prochaine conversation, dis ce que tu penses vraiment plutôt que ce que l'autre veut entendre."],
    ["J'exprime mes besoins et mes désirs ouvertement.","Exprimer ce dont tu as besoin n'est pas un signe de faiblesse. C'est une forme de respect envers toi et les autres."],
    ["Je fais preuve de compassion et d'empathie.","Est-ce que tu te traites avec autant de compassion que tu en accordes aux personnes que tu aimes ?"],
    ["Je suis patiente et compréhensive avec les autres.","La prochaine fois qu'une personne t'agace, prends un instant pour imaginer ce qu'elle traverse."],
    ["Je m'entoure de personnes qui m'élèvent.","Tu deviens un peu la moyenne des personnes que tu fréquentes. Choisis-les avec soin."],
    ["Je crée des liens forts et significatifs.","Quelle relation importante négliges-tu en ce moment et pourquoi ?"],
    ["Je communique avec amour et respect.","Envoie aujourd'hui un message sincère à quelqu'un à qui tu penses souvent mais que tu contactes rarement."],
    ["J'écoute activement et avec bienveillance.","La prochaine fois que quelqu'un te parle, pose ton téléphone et donne-lui toute ton attention."],
    ["Je suis ouverte et honnête dans mes relations.","Y a-t-il quelque chose d'important que tu n'arrives pas à dire à quelqu'un de proche ?"],
    ["J'établis des relations basées sur la confiance.","Tiens aujourd'hui une promesse que tu t'es faite à toi-même ou à quelqu'un d'autre."],
    ["Je soutiens mes amis et ma famille.","Être là pour les autres est une force, à condition de ne pas t'oublier dans l'équation."],
    ["Je fais preuve de gentillesse dans mes interactions.","As-tu été aussi gentille avec toi-même aujourd'hui qu'avec les autres ?"],
    ["Je respecte les différences des autres.","Engage une vraie conversation avec quelqu'un dont le point de vue est différent du tien, avec curiosité plutôt que jugement."],
    ["Je m'exprime avec clarté et confiance.","Ta voix compte. Ce que tu penses mérite d'être entendu."],
    ["Je cultive des relations harmonieuses.","Qu'est-ce que tu pourrais faire différemment pour apporter plus de légèreté à tes relations ?"],
    ["J'attire des personnes qui me font vraiment du bien.","Pense à une personne qui te fait du bien et trouve un moyen de lui montrer que tu apprécies sa présence."],
  ],
  impact:[
    ["Je contribue positivement à ma communauté et à la société.","Tu n'as pas besoin de changer le monde entier. Changer la vie d'une seule personne, c'est déjà immense."],
    ["Mon travail et mes actions ont un impact positif sur le monde.","Quel impact veux-tu avoir dans la vie des personnes qui te croisent ?"],
    ["Je fais une différence positive dans la vie des autres.","Fais aujourd'hui un geste concret, même petit, pour quelqu'un qui ne l'attend pas."],
    ["Mes actions contribuent à un monde meilleur.","Chaque action bienveillante crée une onde qui va plus loin que tu ne le vois."],
    ["Je fais partie de la solution aux problèmes de la société.","Dans quel domaine as-tu envie de faire partie du changement, et qu'est-ce qui t'en empêche ?"],
    ["Je soutiens les causes qui me tiennent à cœur.","Prends cinq minutes pour t'informer ou agir concrètement pour une cause qui te touche."],
    ["Je travaille pour laisser un héritage positif.","L'héritage le plus puissant n'est pas ce qu'on laisse derrière soi mais ce qu'on éveille chez les autres."],
    ["J'inspire les autres par mes actions positives.","Qui dans ta vie t'inspire vraiment et qu'est-ce que tu admires chez cette personne ?"],
    ["Je suis un modèle de positivité pour les autres.","Aujourd'hui, sois consciemment la personne que tu aurais aimé croiser dans un moment difficile de ta vie."],
    ["J'ai un impact positif sur mon environnement.","L'énergie que tu apportes dans une pièce compte. Elle transforme l'atmosphère autour de toi."],
    ["Je m'engage à faire le bien autour de moi.","Où est-ce que tu as le plus d'impact naturellement, sans effort particulier ?"],
    ["Je contribue à la société de manière positive.","Partage aujourd'hui quelque chose qui a de la valeur, une idée, une ressource, une pensée bienveillante."],
    ["Je participe activement à des causes nobles.","S'engager pour quelque chose qui dépasse soi-même donne un sens profond à ce qu'on fait chaque jour."],
    ["Je fais des choix qui bénéficient à la communauté.","Est-ce que tes choix quotidiens sont en accord avec les valeurs que tu veux incarner ?"],
    ["Je travaille pour le bien de la société.","Identifie une compétence que tu as et réfléchis à comment tu pourrais la mettre au service des autres."],
    ["Je suis engagée dans des actions altruistes.","Donner sans attendre en retour est l'une des formes les plus pures de force intérieure."],
    ["Je suis une force pour le bien dans le monde.","Dans quel domaine as-tu envie de t'engager davantage mais tu n'oses pas encore ?"],
    ["Je fais partie d'un changement positif.","Parle aujourd'hui d'une cause qui te tient à cœur à une personne de ton entourage."],
    ["Je fais de mon mieux pour aider les autres.","Faire de son mieux, c'est toujours suffisant. Et ton mieux évolue chaque jour."],
    ["Ma présence au monde est précieuse et nécessaire.","Le monde a besoin de ce que toi seule peux apporter. N'en doute jamais."],
  ],
  manifestation:[
    ["Je suis actrice de la vie que je construis.","Écris aujourd'hui une intention claire pour la semaine à venir, pas un souhait vague, une décision."],
    ["Mes pensées influencent la direction que je prends.","Quelles pensées reviennent le plus souvent dans ta tête et vers où te conduisent-elles ?"],
    ["J'avance avec confiance vers ce que je veux créer.","Tu n'as pas besoin de voir tout le chemin. Juste le prochain pas."],
    ["Je m'ouvre aux opportunités qui se présentent à moi.","Dis oui aujourd'hui à quelque chose que tu aurais normalement décliné par réflexe ou par peur."],
    ["Je suis prête à accueillir ce qui est bon pour moi.","Qu'est-ce qui t'empêche vraiment de recevoir ce que tu dis vouloir ?"],
    ["Je mérite les belles choses qui arrivent dans ma vie.","Les belles choses ne t'arrivent pas par chance. Elles t'arrivent parce que tu les as laissées entrer."],
    ["Mes intentions sont claires, et je pose des actions alignées.","Vérifie aujourd'hui que ce que tu fais est bien aligné avec ce que tu veux vraiment créer."],
    ["J'ai confiance dans le processus, même quand je ne vois pas encore tout.","La graine ne voit pas la fleur qu'elle deviendra. Fais confiance à ce qui pousse en toi."],
    ["Chaque jour, je prends conscience de mon pouvoir de création.","Où as-tu déjà créé quelque chose de beau dans ta vie, et comment l'as-tu fait ?"],
    ["Mes choix et mes actions façonnent ma réalité.","Identifie un choix que tu peux faire aujourd'hui qui te rapproche d'un cran de ta vie idéale."],
    ["Je donne de la valeur à mes idées et à mes envies.","Tes idées ont de la valeur, même celles qui semblent trop grandes ou trop folles."],
    ["Je crois en ce que je veux construire.","Qu'est-ce qui te ferait croire davantage en ce que tu veux créer ?"],
    ["J'attire des opportunités en restant ouverte et attentive.","Aujourd'hui, reste attentive aux synchronicités, aux rencontres, aux signes. Note ce que tu remarques."],
    ["Ce que je construis prend forme, pas à pas.","Ce qui semble lent en cours de route paraît souvent soudain vu de l'extérieur. Continue."],
    ["Je m'autorise à vouloir plus pour ma vie.","Qu'est-ce que tu voudrais vraiment si tu t'autorisais à vouloir sans te censurer ?"],
    ["Je nourris des pensées qui me soutiennent.","Remplace aujourd'hui une pensée limitante récurrente par une pensée qui t'ouvre des possibilités."],
    ["Je prends ma vie en main, un choix à la fois.","Reprendre le pouvoir sur sa vie commence par un seul choix conscient. Lequel feras-tu aujourd'hui ?"],
    ["Je crée des conditions favorables à mes projets.","Identifie une condition qui manque à un projet important et trouve une façon de la créer cette semaine."],
    ["Je mérite l'abondance sous toutes ses formes.","Dans quels domaines de ta vie as-tu du mal à recevoir, et pourquoi selon toi ?"],
    ["Je vois les opportunités là où avant je voyais des blocages.","Ton regard sur les choses a changé. Et quand le regard change, la réalité suit."],
    ["Je me libère de ce qui ne me correspond plus.","Identifie quelque chose qui ne te correspond plus et pose le premier geste pour t'en libérer."],
    ["Je transforme mes envies en décisions.","Une envie reste un rêve. Une décision devient une direction. Tu sais laquelle choisir."],
    ["Je me fais confiance pour créer ma propre voie.","À quel moment as-tu suivi ta propre voie malgré les doutes, et qu'est-ce que ça t'a apporté ?"],
    ["Je m'autorise à recevoir sans culpabiliser.","Accepte aujourd'hui un compliment, une aide ou un cadeau sans le minimiser ni le décliner."],
    ["Je crée de l'espace pour de nouvelles possibilités.","Vider de la place dans ta vie, c'est inviter quelque chose de nouveau à entrer."],
    ["Je suis à l'écoute de ce qui me guide.","Quand tu fais le silence en toi, qu'est-ce que tu entends ?"],
    ["Je construis avec patience et détermination.","La patience n'est pas passive. C'est continuer à agir tout en faisant confiance au temps."],
    ["Ce que j'imagine peut devenir concret avec de l'action.","Prends une idée qui reste dans ta tête depuis trop longtemps et pose-la sur papier avec une première étape."],
    ["Je suis en capacité de créer ce qui me tient à cœur.","Qu'est-ce qui te tient vraiment à cœur et à quand remonte la dernière fois que tu y as consacré du temps ?"],
    ["Je crée une vie qui me ressemble, avec confiance et engagement.","Ta vie est ton œuvre. Crée-la avec autant de soin que tu en mets pour les autres."],
  ],
  legitimite:[
    ["Je suis légitime dans ma place et dans mon rôle.","Ta place ne s'explique pas, elle s'occupe. Tu as tout ce qu'il faut pour être là où tu es."],
    ["J'assume ma posture de leader avec naturel et authenticité.","Qu'est-ce que le leadership signifie pour toi, en dehors de ce qu'on t'a appris à croire ?"],
    ["Ma voix compte et mérite d'être entendue.","Prends la parole aujourd'hui dans un espace où tu aurais tendance à te taire."],
    ["Je n'ai pas besoin de permission pour occuper ma place.","Personne ne viendra te valider. C'est toi qui décides que tu es prête."],
    ["Je reconnais la valeur de ce que j'apporte.","Si une amie avait ton parcours et tes compétences, comment la décrirais-tu ?"],
    ["Je dirige avec bienveillance et clarté.","Exprime aujourd'hui une attente ou une limite clairement, sans t'excuser de l'avoir."],
    ["Je suis capable d'inspirer et d'influencer positivement.","Ton exemple silencieux parle souvent plus fort que n'importe quel discours."],
    ["J'accepte les responsabilités qui correspondent à qui je suis.","Quelle responsabilité tu repousses encore parce que tu ne te sens pas tout à fait légitime ?"],
    ["Je suis à ma place, même quand le doute s'installe.","La prochaine fois que le syndrome de l'imposteur se manifeste, note trois preuves concrètes de ta compétence."],
    ["Mon expérience et mon vécu sont des atouts précieux.","Ce que tu as traversé pour en arriver là fait partie de ce qui te rend unique et précieuse."],
    ["Je m'exprime avec assurance dans les espaces qui comptent.","Dans quels espaces tu retiens encore ta voix et qu'est-ce que tu as peur qu'il se passe si tu t'exprimes ?"],
    ["Je prends des décisions avec confiance et discernement.","Face à une décision qui traîne, fixe-toi une échéance aujourd'hui et décide, même imparfaitement."],
    ["Je mérite les opportunités qui se présentent à moi.","Cette opportunité n'est pas arrivée par erreur. Elle est là parce que tu l'as rendue possible."],
    ["Je construis mon autorité par mes actes et ma cohérence.","En quoi tes actions quotidiennes reflètent-elles la leader que tu veux être ?"],
    ["Je transmets ce que je sais avec générosité et confiance.","Partage aujourd'hui une compétence ou une connaissance avec quelqu'un qui en a besoin, sans en minimiser la valeur."],
    ["J'ose prendre ma place sans attendre que l'on me l'offre.","La table est là. Il te suffit de t'asseoir. Personne d'autre ne le fera à ta place."],
    ["Je revendique mon expertise avec fierté.","Comment parles-tu de ce que tu fais quand on te demande ce que tu fais ?"],
    ["Je suis une femme qui inspire par sa façon d'être autant que de faire.","Aujourd'hui, sois délibérément la version de toi-même que tu admires le plus."],
    ["J'avance sans attendre d'être parfaite pour agir.","La perfectionniste en toi te protège. Mais elle te retient aussi. Il est temps d'avancer quand même."],
    ["Je suis prête à guider, à créer et à laisser ma marque.","Écris en trois phrases la marque que tu veux laisser, dans ton travail, dans ta communauté, dans la vie des autres."],
  ],
};

const ALL_CARDS = CATEGORIES.flatMap(cat =>
  RAW[cat.id].map(([affirmation, message], i) => ({
    id:`${cat.id}-${i}`, affirmation, message, category:cat.label, categoryId:cat.id,
  }))
);

function getAffirmationDuJour() {
  const now = new Date();
  const day = Math.floor((now - new Date(now.getFullYear(),0,0)) / 86400000);
  return ALL_CARDS[day % ALL_CARDS.length];
}

/* ─── CARD COMPONENTS ─── */
function StarPattern({ opacity=0.18 }) {
  return (
    <svg style={{ position:"absolute", inset:0, width:"100%", height:"100%", opacity }} viewBox="0 0 300 420">
      {Array.from({length:30}).map((_,i)=><circle key={i} cx={20+((i*97)%260)} cy={20+((i*73)%380)} r={1+(i%3)} fill={GOLD} opacity={0.35+(i%4)*0.15}/>)}
      <path d="M 30,30 L 45,20 L 30,10 L 15,20 Z" fill="none" stroke={GOLD} strokeWidth="0.8" opacity="0.5"/>
      <path d="M 270,30 L 285,20 L 270,10 L 255,20 Z" fill="none" stroke={GOLD} strokeWidth="0.8" opacity="0.5"/>
      <circle cx="150" cy="210" r="40" fill="none" stroke={GOLD} strokeWidth="0.8" opacity="0.35"/>
      <circle cx="150" cy="210" r="55" fill="none" stroke={GOLD} strokeWidth="0.5" opacity="0.25"/>
      {Array.from({length:12}).map((_,i)=>{const a=(i*30)*Math.PI/180;return <line key={i} x1={150+Math.cos(a)*44} y1={210+Math.sin(a)*44} x2={150+Math.cos(a)*66} y2={210+Math.sin(a)*66} stroke={GOLD} strokeWidth="0.6" opacity="0.25"/>;  })}
    </svg>
  );
}

function CardBorder() {
  return <div style={{ position:"absolute", inset:10, border:`1.5px solid ${GOLD}`, borderRadius:8, opacity:0.38, pointerEvents:"none" }}/>;
}

function HeartBtn({ cardId, favs, onToggle }) {
  const isFav = favs.includes(cardId);
  return (
    <div onClick={e=>{e.stopPropagation();onToggle(cardId);}} style={{ position:"absolute", top:6, right:6, width:44, height:44, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", zIndex:10 }}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill={isFav?PIVOINE:"none"} stroke={isFav?PIVOINE:`rgba(212,168,67,0.55)`} strokeWidth="1.5" style={{ filter:isFav?`drop-shadow(0 0 4px ${PIVOINE}90)`:"none", transition:"all .2s" }}>
        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
      </svg>
    </div>
  );
}

function AffirmCard({ card, favs, onToggleFav, size="normal" }) {
  const big = size==="big";
  return (
    <div style={{ width:"100%", height:"100%", background:`linear-gradient(160deg,${NUIT} 0%,#221040 50%,${PRUNE} 100%)`, borderRadius:16, padding:big?22:16, display:"flex", flexDirection:"column", justifyContent:"space-between", position:"relative", overflow:"hidden" }}>
      <StarPattern opacity={0.15}/>
      <CardBorder/>
      {favs && onToggleFav && <HeartBtn cardId={card.id} favs={favs} onToggle={onToggleFav}/>}

      {/* Catégorie */}
      <div style={{ position:"relative", zIndex:1, textAlign:"center" }}>
        <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:8, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.2em", color:PIVOINE, opacity:0.9 }}>{card.category}</div>
      </div>

      {/* Centre */}
      <div style={{ position:"relative", zIndex:1, textAlign:"center", padding:`0 ${big?10:6}px`, flex:1, display:"flex", flexDirection:"column", justifyContent:"center" }}>
        <div style={{ width:28, height:1.5, background:`linear-gradient(90deg,transparent,${GOLD},transparent)`, margin:"0 auto 14px", opacity:0.7 }}/>

        {/* Affirmation */}
        <p style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:big?21:18, fontWeight:400, fontStyle:"italic", color:"#fff", lineHeight:1.38, margin:"0 0 14px", textShadow:"0 1px 8px rgba(0,0,0,0.3)" }}>{card.affirmation}</p>

        {/* Séparateur */}
        <div style={{ display:"flex", alignItems:"center", gap:8, margin:"0 auto 14px" }}>
          <div style={{ width:16, height:1, background:`linear-gradient(90deg,transparent,${GOLD})`, opacity:0.45 }}/>
          <div style={{ width:4, height:4, borderRadius:"50%", background:GOLD, opacity:0.45 }}/>
          <div style={{ width:16, height:1, background:`linear-gradient(90deg,${GOLD},transparent)`, opacity:0.45 }}/>
        </div>

        {/* Message */}
        <p style={{ fontFamily:"'Raleway',sans-serif", fontSize:big?11.5:11, fontWeight:400, color:"rgba(255,255,255,0.88)", lineHeight:1.65, margin:0, letterSpacing:"0.01em" }}>{card.message}</p>

        <div style={{ width:28, height:1.5, background:`linear-gradient(90deg,transparent,${GOLD},transparent)`, margin:"14px auto 0", opacity:0.7 }}/>
      </div>

      {/* Signature */}
      <div style={{ position:"relative", zIndex:1, textAlign:"center" }}>
        <div style={{ fontFamily:"'Allura',cursive", fontSize:big?20:18, color:ROSE_SAT, lineHeight:1 }}>Être Elles</div>
      </div>
    </div>
  );
}

function CardBack({ size="normal" }) {
  const big = size==="big";
  return (
    <div style={{ width:"100%", height:"100%", background:`linear-gradient(160deg,${NUIT},#221040 50%,${PRUNE})`, borderRadius:16, display:"flex", alignItems:"center", justifyContent:"center", position:"relative", overflow:"hidden" }}>
      <StarPattern opacity={0.25}/>
      <CardBorder/>
      <div style={{ position:"relative", zIndex:1, textAlign:"center" }}>
        <svg width={big?60:44} height={big?60:44} viewBox="0 0 60 60" style={{ margin:"0 auto 12px" }}>
          <circle cx="30" cy="30" r="24" fill="none" stroke={GOLD} strokeWidth="1" opacity="0.55"/>
          <circle cx="30" cy="30" r="16" fill="none" stroke={GOLD} strokeWidth="0.7" opacity="0.4"/>
          <path d="M 30,10 L 34,22 L 46,22 L 36,30 L 40,42 L 30,34 L 20,42 L 24,30 L 14,22 L 26,22 Z" fill={GOLD} opacity="0.35"/>
        </svg>
        <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:10, fontWeight:300, letterSpacing:"0.18em", color:GOLD2, opacity:0.7 }}>appuie pour révéler</div>
      </div>
    </div>
  );
}

/* ─── ORACLE MODE ─── */
function OracleMode({ favs, onToggleFav, dark, zoomedCard, setZoomedCard }) {
  const [selectedCats, setSelectedCats] = useState([]);
  const [cardCount, setCardCount] = useState(1);
  const [phase, setPhase] = useState("idle");
  const [drawnCards, setDrawnCards] = useState([]);
  const [revealedIdx, setRevealedIdx] = useState([]);
  const [configOpen, setConfigOpen] = useState(false);

  const txtMain  = dark ? "rgba(255,255,255,0.72)" : PRUNE;
  const txtMuted = dark ? "rgba(255,255,255,0.38)" : TEXT3;
  const pillOffBg = dark ? "rgba(255,255,255,0.06)" : "rgba(68,48,90,0.06)";
  const pillOffCl = dark ? "rgba(255,255,255,0.55)" : TEXT3;
  const pillOffBd = dark ? "rgba(212,168,67,0.25)" : "rgba(68,48,90,0.15)";

  const pool = selectedCats.length===0 ? ALL_CARDS : ALL_CARDS.filter(c=>selectedCats.includes(c.categoryId));
  const toggleCat = id => setSelectedCats(p=>p.includes(id)?p.filter(c=>c!==id):[...p,id]);

  const pull = () => {
    setDrawnCards(pickRandom(pool, cardCount));
    setRevealedIdx([]);
    setPhase("shuffling");
    setConfigOpen(false);
    setTimeout(()=>setPhase("reveal"), 900);
  };

  const reset = () => { setPhase("idle"); setDrawnCards([]); setRevealedIdx([]); };
  const revealCard = idx => setRevealedIdx(p=>p.includes(idx)?p:[...p,idx]);
  const allRevealed = drawnCards.length>0 && revealedIdx.length===drawnCards.length;
  const cardW = cardCount===1?300:cardCount===2?240:190;
  const cardH = cardCount===1?460:cardCount===2?360:290;

  const COUNT_OPTS = [
    {n:1,label:"Une carte",sub:"Une intention pour la journée"},
    {n:2,label:"Deux cartes",sub:"Un regard croisé"},
    {n:3,label:"Trois cartes",sub:"Corps, tête, cœur"},
  ];

  const configSummary = [
    selectedCats.length===0 ? "Toutes les thématiques" : `${selectedCats.length} thématique${selectedCats.length>1?"s":""}`,
    `${cardCount} carte${cardCount>1?"s":""}`,
  ].join(" · ");

  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", padding:"20px 20px 32px" }}>

      {phase==="idle" && (
        <>
          {/* Fan */}
          <div style={{ position:"relative", width:"100%", maxWidth:420, height:210, margin:"0 auto" }}>
            {Array.from({length:7}).map((_,i)=>(
              <div key={i} style={{ position:"absolute", width:130, height:190, left:"50%", bottom:0, transformOrigin:"bottom center", transform:`translateX(-50%) rotate(${-36+i*12}deg) translateX(${-90+i*30}px)`, background:`linear-gradient(160deg,${NUIT},#221040 60%,${PRUNE})`, borderRadius:12, border:`1px solid ${GOLD}28`, boxShadow:`0 8px 28px rgba(0,0,0,0.4)`, overflow:"hidden", zIndex:i }}>
                <div style={{ position:"absolute", inset:8, border:`1px solid ${GOLD}20`, borderRadius:7 }}/>
                <div style={{ position:"absolute", inset:0, backgroundImage:`radial-gradient(circle at 50% 30%,rgba(212,168,67,0.07) 0%,transparent 65%)` }}/>
                <div style={{ position:"absolute", top:"50%", left:"50%", transform:"translate(-50%,-50%)" }}>
                  <svg width="28" height="28" viewBox="0 0 20 20"><path d="M 10,2 L 12,8 L 18,8 L 13,12 L 15,18 L 10,14 L 5,18 L 7,12 L 2,8 L 8,8 Z" fill={GOLD} opacity="0.32"/></svg>
                </div>
              </div>
            ))}
          </div>

          {/* Texte + bouton Personnaliser + config accordéon + bouton Tirer */}
          <div style={{ position:"relative", zIndex:10, width:"100%", maxWidth:500, marginTop:100, display:"flex", flexDirection:"column", alignItems:"center", gap:16 }}>

            <p style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:18, fontStyle:"italic", color:txtMain, textAlign:"center", margin:0 }}>
              Choisis tes thématiques et ton tirage.
            </p>

            {/* Bouton Personnaliser */}
            <button onClick={()=>setConfigOpen(o=>!o)} style={{
              fontFamily:"'Raleway',sans-serif", fontSize:12, fontWeight:600,
              padding:"8px 20px", borderRadius:20, cursor:"pointer", transition:"all .2s",
              border:`1px solid ${dark?`${GOLD}40`:"rgba(68,48,90,0.2)"}`,
              background: configOpen ? (dark?"rgba(255,255,255,0.1)":"rgba(68,48,90,0.08)") : "transparent",
              color: dark ? GOLD2 : PRUNE,
              display:"flex", alignItems:"center", gap:6,
            }}>
              <span style={{ fontSize:10, transition:"transform .25s", display:"inline-block", transform:configOpen?"rotate(180deg)":"rotate(0deg)" }}>▾</span>
              Personnaliser
              <span style={{ fontFamily:"'Raleway',sans-serif", fontSize:10, fontWeight:300, color:dark?"rgba(255,255,255,0.4)":"rgba(68,48,90,0.4)", marginLeft:2 }}>{configSummary}</span>
            </button>

            {/* Panneau accordéon */}
            {configOpen && (
              <div style={{ width:"100%", animation:"fadeDown .25s ease" }}>
                {/* Nombre de cartes */}
                <div style={{ marginBottom:16 }}>
                  <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:9, fontWeight:700, letterSpacing:"0.2em", textTransform:"uppercase", color:PIVOINE, opacity:0.85, marginBottom:10, textAlign:"center" }}>Nombre de cartes</div>
                  <div style={{ display:"flex", gap:10 }}>
                    {COUNT_OPTS.map(({n,label,sub})=>(
                      <button key={n} onClick={()=>setCardCount(n)} style={{ flex:1, padding:"12px 6px", borderRadius:12, cursor:"pointer", transition:"all .2s", border:cardCount===n?`2px solid ${PIVOINE}`:`1px solid ${dark?`${GOLD}22`:"rgba(68,48,90,0.15)"}`, background:cardCount===n?"rgba(200,99,122,0.18)":dark?"rgba(255,255,255,0.04)":"rgba(68,48,90,0.04)", boxShadow:cardCount===n?`0 0 14px ${PIVOINE}30`:"none", display:"flex", flexDirection:"column", alignItems:"center", gap:5 }}>
                        <div style={{ display:"flex", gap:3 }}>{Array.from({length:n}).map((_,i)=><div key={i} style={{ width:8, height:14, borderRadius:2, background:cardCount===n?PIVOINE:dark?GOLD:"rgba(68,48,90,0.3)", opacity:cardCount===n?1:0.5 }}/>)}</div>
                        <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:11, fontWeight:600, color:cardCount===n?PIVOINE:dark?GOLD2:PRUNE, opacity:cardCount===n?1:0.6 }}>{label}</div>
                        <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:9.5, fontWeight:300, color:cardCount===n?"rgba(255,255,255,0.6)":dark?"rgba(255,255,255,0.28)":TEXT4, textAlign:"center", lineHeight:1.3 }}>{sub}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Thématiques */}
                <div>
                  <div style={{ display:"flex", alignItems:"baseline", justifyContent:"space-between", marginBottom:10 }}>
                    <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:9, fontWeight:700, letterSpacing:"0.2em", textTransform:"uppercase", color:PIVOINE, opacity:0.85 }}>Thématique(s)</div>
                    <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:10, color:dark?"rgba(255,255,255,0.35)":TEXT4 }}>{selectedCats.length===0?"Toutes":`${pool.length} cartes`}</div>
                  </div>
                  <div style={{ display:"flex", flexWrap:"wrap", gap:7 }}>
                    {CATEGORIES.map(cat=>{
                      const on=selectedCats.includes(cat.id);
                      return <button key={cat.id} onClick={()=>toggleCat(cat.id)} style={{ fontFamily:"'Raleway',sans-serif", fontSize:11, fontWeight:on?600:300, padding:"6px 14px", borderRadius:20, cursor:"pointer", transition:"all .2s", border:on?"none":`0.5px solid ${pillOffBd}`, background:on?PIVOINE:pillOffBg, color:on?"#fff":pillOffCl, boxShadow:on?`0 2px 8px ${PIVOINE}35`:"none" }}>{cat.label}</button>;
                    })}
                  </div>
                  {selectedCats.length>0&&<button onClick={()=>setSelectedCats([])} style={{ fontFamily:"'Raleway',sans-serif", fontSize:11, color:dark?"rgba(255,255,255,0.35)":TEXT4, background:"none", border:"none", cursor:"pointer", marginTop:8, padding:0 }}>Tout effacer</button>}
                </div>
              </div>
            )}

            {/* Bouton Tirer */}
            <button onClick={pull} style={{ fontFamily:"'Raleway',sans-serif", fontSize:15, fontWeight:600, padding:"16px 52px", borderRadius:50, border:"none", background:PIVOINE, color:"#fff", cursor:"pointer", boxShadow:`0 6px 24px ${PIVOINE}55`, animation:"gentleBob 2.5s ease-in-out infinite", marginTop:4 }}>
              ✦ Tirer {cardCount>1?`${cardCount} cartes`:"une carte"}
            </button>
          </div>
        </>
      )}

      {phase==="shuffling" && (
        <div style={{ textAlign:"center", padding:"60px 0" }}>
          <div style={{ width:90, height:125, margin:"0 auto 20px", background:`linear-gradient(160deg,${NUIT},${PRUNE})`, borderRadius:12, border:`1px solid ${GOLD}30`, animation:"shuffle .9s ease", display:"flex", alignItems:"center", justifyContent:"center" }}>
            <svg width="28" height="28" viewBox="0 0 24 24"><path d="M 12,3 L 14,9 L 20,9 L 15,13 L 17,19 L 12,15 L 7,19 L 9,13 L 4,9 L 10,9 Z" fill={GOLD} opacity="0.5"/></svg>
          </div>
          <p style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:16, fontStyle:"italic", color:txtMuted }}>Mélange en cours...</p>
        </div>
      )}

      {phase==="reveal" && (
        <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:20, width:"100%" }}>

          {/* Aperçu miniature des cartes */}
          <div style={{ display:"flex", gap:14, justifyContent:"center", flexWrap:cardCount===3?"wrap":"nowrap", width:"100%", maxWidth:680 }}>
            {drawnCards.map((card,idx)=>{
              const revealed = revealedIdx.includes(idx);
              return (
                <div key={card.id}
                  onClick={()=>{ if(!revealed) revealCard(idx); setZoomedCard(card); }}
                  style={{ width:cardW, height:cardH, cursor:"pointer", flexShrink:0, position:"relative", zIndex:1, borderRadius:16, transition:"opacity .2s", opacity: revealed ? 1 : 0.85 }}>
                  {revealed
                    ? <AffirmCard card={card} favs={favs} onToggleFav={onToggleFav} size="normal"/>
                    : <CardBack size="normal"/>
                  }
                </div>
              );
            })}
          </div>

          {!allRevealed && <p style={{ fontFamily:"'Raleway',sans-serif", fontSize:12, fontWeight:300, color:txtMuted, textAlign:"center" }}>{revealedIdx.length===0?"Appuie sur une carte pour la révéler.":`${drawnCards.length-revealedIdx.length} carte${drawnCards.length-revealedIdx.length>1?"s":""} restante${drawnCards.length-revealedIdx.length>1?"s":""}.`}</p>}

          <button onClick={reset} style={{ fontFamily:"'Raleway',sans-serif", fontSize:13, fontWeight:600, padding:"12px 32px", borderRadius:50, border:`1px solid ${PIVOINE}55`, background:"transparent", color:PIVOINE, cursor:"pointer" }}>
            ↺ {allRevealed ? "Nouveau tirage" : "Recommencer"}
          </button>

        </div>
      )}
    </div>
  );
}

/* ─── DECK MODE ─── */
function DeckMode({ cards, currentIdx, onPrev, onNext, favs, onToggleFav, dark }) {
  const hasPrev=currentIdx>0, hasNext=currentIdx<cards.length-1;
  const [dir, setDir] = useState(null); // "left" | "right"

  const goNext = () => { setDir("right"); onNext(); };
  const goPrev = () => { setDir("left");  onPrev(); };

  const animKey = `${currentIdx}-${dir}`;

  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", padding:"24px 24px 32px" }}>
      <div style={{ position:"relative", width:"100%", maxWidth:520, height:480, display:"flex", alignItems:"center", justifyContent:"center" }}>
        {hasPrev&&(
          <div onClick={goPrev} style={{ position:"absolute", width:280, height:400, left:"50%", top:"50%", transform:"translate(-78%,-50%) rotate(-8deg) scale(0.85)", cursor:"pointer", opacity:0.55, transition:"all .35s", zIndex:1 }}>
            <AffirmCard card={cards[currentIdx-1]}/>
          </div>
        )}
        <div key={animKey} style={{ position:"relative", width:320, height:460, zIndex:3, animation: dir==="right" ? "slideFromRight .4s ease" : dir==="left" ? "slideFromLeft .4s ease" : "cardIn .35s ease" }}>
          <AffirmCard card={cards[currentIdx]} favs={favs} onToggleFav={onToggleFav} size="big"/>
        </div>
        {hasNext&&(
          <div onClick={goNext} style={{ position:"absolute", width:280, height:400, left:"50%", top:"50%", transform:"translate(-22%,-50%) rotate(8deg) scale(0.85)", cursor:"pointer", opacity:0.55, transition:"all .35s", zIndex:1 }}>
            <AffirmCard card={cards[currentIdx+1]}/>
          </div>
        )}
      </div>
      <div style={{ display:"flex", alignItems:"center", gap:24, marginTop:12 }}>
        <button onClick={goPrev} disabled={!hasPrev} style={{ width:48, height:48, borderRadius:"50%", border:`1px solid ${!hasPrev?"rgba(45,42,51,0.08)":"rgba(45,42,51,0.18)"}`, background:!hasPrev?"transparent":"#fff", color:!hasPrev?TEXT5:"#2d2a33", cursor:!hasPrev?"default":"pointer", fontSize:20, display:"flex", alignItems:"center", justifyContent:"center" }}>←</button>
        <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:12, color:dark?"rgba(255,255,255,0.45)":TEXT4 }}>{currentIdx+1} / {cards.length}</div>
        <button onClick={goNext} disabled={!hasNext} style={{ width:48, height:48, borderRadius:"50%", border:"none", background:!hasNext?"rgba(45,42,51,0.06)":PIVOINE, color:!hasNext?TEXT5:"#fff", cursor:!hasNext?"default":"pointer", fontSize:20, display:"flex", alignItems:"center", justifyContent:"center", boxShadow:!hasNext?"none":`0 2px 10px ${PIVOINE}50` }}>→</button>
      </div>
    </div>
  );
}

/* ─── FAVORIS ─── */
function FavsMode({ favs, onToggleFav, dark }) {
  const favCards = ALL_CARDS.filter(c=>favs.includes(c.id));
  const txtMain  = dark?"rgba(255,255,255,0.6)":PRUNE;
  const txtMuted = dark?"rgba(255,255,255,0.35)":TEXT3;
  if (!favCards.length) return (
    <div style={{ textAlign:"center", padding:"60px 24px" }}>
      <p style={{ fontFamily:"'Cormorant Garamond',serif", fontStyle:"italic", fontSize:20, color:txtMain, marginBottom:8 }}>Aucune carte sauvegardée.</p>
      <p style={{ fontFamily:"'Raleway',sans-serif", fontSize:13, fontWeight:300, color:txtMuted }}>Appuie sur ♡ sur une carte pour l'ajouter ici.</p>
    </div>
  );
  return (
    <div style={{ padding:"16px 20px 32px", display:"flex", flexDirection:"column", gap:20, alignItems:"center" }}>
      {favCards.map(card=><div key={card.id} style={{ width:"100%", maxWidth:360, height:460 }}><AffirmCard card={card} favs={favs} onToggleFav={onToggleFav} size="big"/></div>)}
    </div>
  );
}

/* ─── AIDE ─── */
function AideMode({ dark }) {
  const [notifStatus, setNotifStatus] = useState(Notification?.permission||"default");
  const [notifTime, setNotifTime] = useState(()=>localStorage.getItem("ee-notif-time")||"08:00");
  const [saved, setSaved] = useState(false);

  useEffect(()=>{ registerSW(); },[]);

  const handlePermission = async () => {
    const r = await Notification.requestPermission();
    setNotifStatus(r);
    if (r==="granted") { scheduleNotif(notifTime); localStorage.setItem("ee-notif-time",notifTime); }
  };
  const handleSave = () => {
    localStorage.setItem("ee-notif-time",notifTime);
    if (notifStatus==="granted") scheduleNotif(notifTime);
    setSaved(true); setTimeout(()=>setSaved(false),2000);
  };

  const txt   = dark?"rgba(255,255,255,0.82)":PRUNE;
  const muted = dark?"rgba(255,255,255,0.42)":TEXT3;
  const cs = { background:dark?"rgba(255,255,255,0.05)":"rgba(68,48,90,0.04)", border:dark?`1px solid ${GOLD}20`:"1px solid rgba(68,48,90,0.1)", borderRadius:14, padding:"18px", marginBottom:14 };
  const ss = { display:"flex", gap:12, alignItems:"flex-start", marginBottom:12 };
  const ns = { width:28, height:28, borderRadius:"50%", background:PIVOINE, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Raleway',sans-serif", fontWeight:700, fontSize:13, color:"#fff", flexShrink:0 };
  const h3s = { fontFamily:"'Cormorant Garamond',serif", fontStyle:"italic", fontSize:17, color:dark?GOLD2:PRUNE, marginBottom:12, display:"flex", alignItems:"center", gap:8 };
  const ps = { fontFamily:"'Raleway',sans-serif", fontSize:13, fontWeight:300, color:txt, lineHeight:1.7, margin:0 };

  return (
    <div style={{ padding:"16px 20px 32px", maxWidth:540, margin:"0 auto" }}>

      <div style={cs}>
        <div style={h3s}>✦ Premiers pas</div>
        {[
          ["Mon tirage","Appuie sur ⚙ Personnaliser pour choisir ta thématique et le nombre de cartes. Reviens sur Mon tirage et appuie sur le bouton pour tirer. Chaque carte se révèle au toucher."],
          ["La Collection","Parcours toutes les cartes ou filtre par thématique. Navigue avec les flèches ou en appuyant sur les cartes adjacentes."],
          ["Favoris ♡","Appuie sur le cœur en haut à droite d'une carte pour la sauvegarder. Retrouve tes cartes préférées dans l'onglet Favoris."],
          ["Affirmation du jour","Une carte t'attend chaque matin en haut de l'app. Elle change automatiquement chaque jour. Laisse-la guider ton intention."],
          ["Mode clair / sombre","Le mode s'ajuste selon l'heure. Tu peux aussi le changer manuellement avec le bouton ☀ / ◑ en haut à droite."],
        ].map(([t,d],i)=>(
          <div key={i} style={ss}>
            <div style={ns}>{i+1}</div>
            <div><div style={{ ...ps, fontWeight:600, marginBottom:2 }}>{t}</div><div style={ps}>{d}</div></div>
          </div>
        ))}
      </div>

      <div style={{ ...cs, borderColor:dark?`${PIVOINE}35`:"rgba(200,99,122,0.2)", background:dark?"rgba(200,99,122,0.06)":"rgba(200,99,122,0.04)" }}>
        <div style={h3s}>🔔 Rappel quotidien</div>
        <div style={{ ...ps, marginBottom:14 }}>Reçois chaque jour une notification pour ne jamais oublier ton rituel. L'app doit être installée sur ton téléphone.</div>
        {notifStatus==="granted"?(
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            <div style={{ display:"flex", alignItems:"center", gap:10, flexWrap:"wrap" }}>
              <div style={{ ...ps, fontSize:12 }}>Heure :</div>
              <input type="time" value={notifTime} onChange={e=>setNotifTime(e.target.value)} style={{ fontFamily:"'Raleway',sans-serif", fontSize:14, padding:"6px 12px", borderRadius:10, border:`1px solid ${GOLD}40`, background:dark?"rgba(255,255,255,0.08)":"rgba(68,48,90,0.06)", color:dark?"#fff":PRUNE, cursor:"pointer" }}/>
              <button onClick={handleSave} style={{ fontFamily:"'Raleway',sans-serif", fontSize:12, fontWeight:600, padding:"7px 20px", borderRadius:20, border:"none", background:saved?"rgba(100,180,100,0.8)":PIVOINE, color:"#fff", cursor:"pointer" }}>{saved?"✓ Enregistré":"Enregistrer"}</button>
            </div>
            <div style={{ ...ps, color:muted, fontSize:11 }}>✓ Rappel programmé à {notifTime}</div>
          </div>
        ):notifStatus==="denied"?(
          <div style={{ ...ps, color:muted }}>Notifications refusées. Active-les dans les réglages de ton navigateur.</div>
        ):(
          <button onClick={handlePermission} style={{ fontFamily:"'Raleway',sans-serif", fontSize:13, fontWeight:600, padding:"11px 28px", borderRadius:30, border:`1px solid ${PIVOINE}55`, background:"transparent", color:PIVOINE, cursor:"pointer" }}>Activer les rappels</button>
        )}
      </div>

      <div style={cs}>
        <div style={h3s}><span>🍎</span> Installer sur iPhone</div>
        {["Ouvre cette page dans Safari (pas Chrome ni Firefox).","Appuie sur le bouton Partager ↑ en bas de l'écran.","Sélectionne « Sur l'écran d'accueil ».","Nomme l'app « Ritu'Elles » puis appuie sur « Ajouter ».","L'icône apparaît sur ton écran d'accueil."].map((t,i)=>(
          <div key={i} style={ss}><div style={ns}>{i+1}</div><div style={ps}>{t}</div></div>
        ))}
        <div style={{ ...ps, color:muted, fontSize:11 }}>Compatible iPhone et iPad · iOS 14+</div>
      </div>

      <div style={cs}>
        <div style={h3s}><span>🤖</span> Installer sur Android</div>
        {["Ouvre cette page dans Chrome.","Appuie sur les trois points ⋮ en haut à droite.","Sélectionne « Ajouter à l'écran d'accueil ».","Nomme l'app « Ritu'Elles » puis appuie sur « Ajouter »."].map((t,i)=>(
          <div key={i} style={ss}><div style={ns}>{i+1}</div><div style={ps}>{t}</div></div>
        ))}
        <div style={{ ...ps, color:muted, fontSize:11 }}>Compatible Android 8+</div>
      </div>

      <div style={{ ...cs, borderColor:dark?`${PIVOINE}40`:"rgba(200,99,122,0.2)", background:dark?"rgba(200,99,122,0.07)":"rgba(200,99,122,0.04)" }}>
        <div style={h3s}>♡ Rejoindre la communauté</div>
        <div style={ps}>Retrouve les défis, ressources et la communauté Être Elles sur Skool pour aller encore plus loin dans ton développement.</div>
        <a href="https://www.skool.com/etre-elles-8949" target="_blank" rel="noopener noreferrer" style={{ display:"inline-block", marginTop:14, fontFamily:"'Raleway',sans-serif", fontSize:13, fontWeight:600, padding:"10px 28px", borderRadius:30, background:PIVOINE, color:"#fff", textDecoration:"none" }}>Rejoindre Être Elles</a>
      </div>
    </div>
  );
}

/* ─── APP ─── */
window.App = function App() {
  const hour = new Date().getHours();
  const [dark, setDark] = useState(hour>=12);
  const [mode, setMode] = useState("oracle");
  const [zoomedCard, setZoomedCard] = useState(null);
  const [catId, setCatId] = useState("all");
  const [currentIdx, setCurrentIdx] = useState(0);
  const [favs, setFavs] = useState(()=>{ try { return JSON.parse(localStorage.getItem("ee-favs")||"[]"); } catch { return []; } });

  useEffect(()=>{ registerSW(); },[]);
  const filteredCards = catId==="all" ? ALL_CARDS : ALL_CARDS.filter(c=>c.categoryId===catId);
  useEffect(()=>{ setCurrentIdx(0); },[catId,mode]);

  const toggleFav = useCallback(id=>{
    setFavs(prev=>{
      const next=prev.includes(id)?prev.filter(f=>f!==id):[...prev,id];
      try { localStorage.setItem("ee-favs",JSON.stringify(next)); } catch {}
      return next;
    });
  },[]);

  const affDuJour = getAffirmationDuJour();
  const pageBg = dark?`linear-gradient(160deg,${DARK_PAGE} 0%,${DARK_PAGE2} 100%)`:AUBE;
  const heroTxt = dark?"rgba(255,255,255,0.58)":TEXT3;
  const modeOffBg = dark?"rgba(255,255,255,0.07)":"rgba(68,48,90,0.05)";
  const modeOffCl = dark?"rgba(255,255,255,0.45)":TEXT4;
  const pillOff = dark?{bg:"rgba(255,255,255,0.06)",cl:"rgba(255,255,255,0.5)",bd:"rgba(255,255,255,0.1)"}:{bg:"rgba(68,48,90,0.04)",cl:TEXT3,bd:"rgba(68,48,90,0.12)"};
  const todayLbl = dark?GOLD2:"#9A7010";
  const todayTxt = dark?"rgba(255,255,255,0.78)":"#2d2a33";

  const TABS = [
    {id:"oracle",lbl:"✦ Mon tirage"},
    {id:"deck",  lbl:"La Collection"},
    {id:"favs",  lbl:`♡ Favoris${favs.length?` (${favs.length})`:""}`},
    {id:"aide",  lbl:"? Aide"},
  ];

  return (
    <div style={{ fontFamily:"'Raleway',sans-serif", background:pageBg, minHeight:"100vh", position:"relative", transition:"background .4s", color:dark?"#fff":"#2d2a33" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@1,400;1,500&family=Raleway:wght@300;400;600&family=Inter:wght@700;900&family=Allura&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        @keyframes cardIn{0%{opacity:0;transform:perspective(800px) rotateY(-12deg) scale(0.96);}100%{opacity:1;transform:perspective(800px) rotateY(0deg) scale(1);}}
        @keyframes slideFromRight{0%{opacity:0;transform:perspective(800px) rotateY(-20deg) translateX(60px) scale(0.9);}100%{opacity:1;transform:perspective(800px) rotateY(0deg) translateX(0) scale(1);}}
        @keyframes slideFromLeft{0%{opacity:0;transform:perspective(800px) rotateY(20deg) translateX(-60px) scale(0.9);}100%{opacity:1;transform:perspective(800px) rotateY(0deg) translateX(0) scale(1);}}
        @keyframes popForward{0%{transform:perspective(600px) rotateY(90deg) scale(0.85);}60%{transform:perspective(600px) rotateY(-8deg) scale(1.06);}100%{transform:perspective(600px) rotateY(0deg) scale(1);}}
        @keyframes shuffle{0%{transform:translateX(0) rotate(0deg);}25%{transform:translateX(-20px) rotate(-5deg);}50%{transform:translateX(20px) rotate(5deg);}75%{transform:translateX(-10px) rotate(-3deg);}100%{transform:translateX(0) rotate(0deg);}}
        @keyframes gentleBob{0%,100%{transform:translateY(0);}50%{transform:translateY(-4px);}}
        @keyframes twinkle{0%,100%{opacity:0.08;}50%{opacity:0.28;}}
        @keyframes fadeDown{0%{opacity:0;transform:translateY(-8px);}100%{opacity:1;transform:translateY(0);}}
        ::-webkit-scrollbar{width:4px;height:4px;}
        ::-webkit-scrollbar-thumb{background:rgba(212,168,67,0.22);border-radius:2px;}
        input[type=time]{color-scheme:dark;}
      `}</style>

      {!dark&&(
        <div style={{ position:"absolute", inset:0, overflow:"hidden", pointerEvents:"none", zIndex:0 }}>
          <div style={{ position:"absolute", inset:0, backgroundImage:`radial-gradient(circle,rgba(200,99,122,0.04) 1px,transparent 1px)`, backgroundSize:"32px 32px" }}/>
          <svg style={{ position:"absolute", top:-20, right:-40, width:360, height:440, opacity:0.4, transform:"scaleX(-1)" }} viewBox="0 0 360 440" fill="none">
            <path d="M 0,0 L 280,0 L 284,8 L 276,20 L 288,28 L 274,42 L 290,50 L 278,64 L 294,76 L 280,88 L 292,102 L 278,114 L 290,128 L 276,142 L 288,156 L 274,170 L 290,184 L 278,198 L 292,212 L 278,228 L 286,244 L 272,260 L 284,276 L 270,292 L 260,308 L 244,320 L 224,334 L 200,344 L 168,356 L 130,366 L 80,378 L 30,388 L 0,396 Z" fill={VIEUX}/>
            {Array.from({length:20}).map((_,r)=>Array.from({length:15}).map((_,c)=><rect key={`tr${r}-${c}`} x={12+c*18} y={10+r*18} width="18" height="18" fill="none" stroke="rgba(200,99,122,0.1)" strokeWidth="0.6"/>))}
          </svg>
          <svg style={{ position:"absolute", bottom:-30, left:-50, width:320, height:300, opacity:0.32, transform:"rotate(-4deg)" }} viewBox="0 0 320 300" fill="none">
            <path d="M 0,0 L 320,0 L 320,250 Q 306,260 294,248 Q 280,262 266,246 Q 254,260 240,244 Q 228,258 214,242 Q 200,258 186,240 Q 174,256 160,238 Q 148,254 134,236 Q 122,252 108,234 Q 96,250 82,232 Q 68,248 54,230 Q 42,246 28,228 Q 14,244 0,226 Z" fill={AUBE}/>
            {Array.from({length:13}).map((_,r)=>Array.from({length:17}).map((_,c)=><rect key={`bl${r}-${c}`} x={8+c*18} y={8+r*18} width="18" height="18" fill="none" stroke="rgba(200,99,122,0.08)" strokeWidth="0.6"/>))}
          </svg>
          {[{x:10,y:6,s:38,o:0.1,d:6,dl:0},{x:82,y:20,s:30,o:0.08,d:7,dl:1.5},{x:15,y:60,s:34,o:0.09,d:5.5,dl:.8}].map((p,i)=>(
            <div key={i} style={{ position:"absolute", left:`${p.x}%`, top:`${p.y}%` }}><div style={{ fontSize:p.s, color:PIVOINE, opacity:p.o, animation:`twinkle ${p.d}s ease-in-out ${p.dl}s infinite`, userSelect:"none" }}>✦</div></div>
          ))}
        </div>
      )}
      {dark&&(
        <div style={{ position:"absolute", inset:0, overflow:"hidden", pointerEvents:"none", zIndex:0 }}>
          <div style={{ position:"absolute", inset:0, backgroundImage:`radial-gradient(circle at 30% 20%,rgba(155,114,207,0.09) 0%,transparent 55%),radial-gradient(circle at 70% 80%,rgba(200,99,122,0.06) 0%,transparent 45%)` }}/>
          <div style={{ position:"absolute", inset:0, backgroundImage:`repeating-linear-gradient(90deg,rgba(155,114,207,0.03) 0px,rgba(155,114,207,0.03) 1px,transparent 1px,transparent 56px),repeating-linear-gradient(0deg,rgba(155,114,207,0.03) 0px,rgba(155,114,207,0.03) 1px,transparent 1px,transparent 56px)` }}/>
          <svg style={{ position:"absolute", top:-20, right:-40, width:360, height:440, opacity:0.18, transform:"scaleX(-1)" }} viewBox="0 0 360 440" fill="none">
            <path d="M 0,0 L 280,0 L 284,8 L 276,20 L 288,28 L 274,42 L 290,50 L 278,64 L 294,76 L 280,88 L 292,102 L 278,114 L 290,128 L 276,142 L 288,156 L 274,170 L 290,184 L 278,198 L 292,212 L 278,228 L 286,244 L 272,260 L 284,276 L 270,292 L 260,308 L 244,320 L 224,334 L 200,344 L 168,356 L 130,366 L 80,378 L 30,388 L 0,396 Z" fill={PRUNE}/>
            {Array.from({length:20}).map((_,r)=>Array.from({length:15}).map((_,c)=><rect key={`tr${r}-${c}`} x={12+c*18} y={10+r*18} width="18" height="18" fill="none" stroke="rgba(155,114,207,0.12)" strokeWidth="0.6"/>))}
          </svg>
          <svg style={{ position:"absolute", bottom:-30, left:-50, width:320, height:300, opacity:0.15, transform:"rotate(-4deg)" }} viewBox="0 0 320 300" fill="none">
            <path d="M 0,0 L 320,0 L 320,250 Q 306,260 294,248 Q 280,262 266,246 Q 254,260 240,244 Q 228,258 214,242 Q 200,258 186,240 Q 174,256 160,238 Q 148,254 134,236 Q 122,252 108,234 Q 96,250 82,232 Q 68,248 54,230 Q 42,246 28,228 Q 14,244 0,226 Z" fill={DARK_PAGE2}/>
            {Array.from({length:13}).map((_,r)=>Array.from({length:17}).map((_,c)=><rect key={`bl${r}-${c}`} x={8+c*18} y={8+r*18} width="18" height="18" fill="none" stroke="rgba(155,114,207,0.08)" strokeWidth="0.6"/>))}
          </svg>
          {[{x:8,y:8,s:40,o:0.12,d:7,dl:0},{x:85,y:16,s:32,o:0.1,d:6,dl:2},{x:14,y:68,s:36,o:0.11,d:5.5,dl:1}].map((p,i)=>(
            <div key={i} style={{ position:"absolute", left:`${p.x}%`, top:`${p.y}%`, pointerEvents:"none" }}><div style={{ fontSize:p.s, color:LILAS_L, opacity:p.o, animation:`twinkle ${p.d}s ease-in-out ${p.dl}s infinite`, userSelect:"none" }}>✦</div></div>
          ))}
        </div>
      )}

      <div style={{ position:"relative", zIndex:1, padding:"36px 20px 0", textAlign:"center", maxWidth:720, margin:"0 auto" }}>
        <div style={{ position:"absolute", top:36, right:20, display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
          <button onClick={()=>setDark(d=>!d)} style={{ width:44, height:44, borderRadius:"50%", border:`1.5px solid ${dark?"rgba(200,176,232,0.3)":"rgba(68,48,90,0.2)"}`, background:dark?"rgba(255,255,255,0.08)":"rgba(68,48,90,0.06)", cursor:"pointer", fontSize:18, color:dark?LILAS_L:PRUNE, display:"flex", alignItems:"center", justifyContent:"center" }}>
            {dark?"☀":"◑"}
          </button>
          <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:8, fontWeight:600, letterSpacing:"0.08em", color:dark?LILAS_L:PRUNE, opacity:0.6 }}>{dark?"Soir":"Matin"}</div>
        </div>

        <div style={{ fontFamily:"'Allura',cursive", fontSize:52, color:dark?ROSE_SAT:PRUNE, lineHeight:1, marginBottom:2 }}>Ritu'Elles</div>
        <p style={{ fontFamily:"'Cormorant Garamond',serif", fontStyle:"italic", fontSize:15, color:heroTxt, margin:"0 0 14px" }}>
          Un rituel d'affirmations positives, chaque jour.
        </p>

        <div style={{ display:"inline-flex", alignItems:"center", gap:8, background:"rgba(212,168,67,0.07)", border:`1px solid ${GOLD}28`, borderRadius:18, padding:"7px 16px", marginBottom:20, maxWidth:500, flexWrap:"wrap", justifyContent:"center" }}>
          <span style={{ fontFamily:"'Raleway',sans-serif", fontSize:8, fontWeight:700, letterSpacing:"0.18em", textTransform:"uppercase", color:todayLbl, flexShrink:0 }}>✦ Aujourd'hui</span>
          <span style={{ fontFamily:"'Cormorant Garamond',serif", fontStyle:"italic", fontSize:13, color:todayTxt }}>{affDuJour.affirmation}</span>
        </div>

        <div style={{ display:"inline-flex", gap:4, background:dark?"rgba(255,255,255,0.06)":"rgba(68,48,90,0.05)", borderRadius:28, padding:4, flexWrap:"wrap", justifyContent:"center" }}>
          {TABS.map(({id,lbl})=>(
            <button key={id} onClick={()=>setMode(id)} style={{ fontFamily:"'Raleway',sans-serif", fontSize:12, fontWeight:mode===id?600:400, padding:"8px 20px", borderRadius:22, border:"none", cursor:"pointer", transition:"all .2s", background:mode===id?PIVOINE:"transparent", color:mode===id?"#fff":modeOffCl }}>{lbl}</button>
          ))}
        </div>
      </div>

      {mode==="deck"&&(
        <div style={{ position:"relative", zIndex:1, padding:"16px 0 4px" }}>
          <div style={{ position:"relative" }}>
            <div style={{ overflowX:"auto", WebkitOverflowScrolling:"touch", display:"flex", gap:8, padding:"0 20px", scrollbarWidth:"none" }}>
              {[{id:"all",label:`Toutes (${ALL_CARDS.length})`},...CATEGORIES].map(cat=>{
                const on=catId===cat.id;
                return <button key={cat.id} onClick={()=>setCatId(cat.id)} style={{ fontFamily:"'Raleway',sans-serif", fontSize:11, fontWeight:on?600:300, padding:"7px 16px", borderRadius:20, cursor:"pointer", whiteSpace:"nowrap", transition:"all .2s", flexShrink:0, border:on?"none":`0.5px solid ${pillOff.bd}`, background:on?PIVOINE:pillOff.bg, color:on?"#fff":pillOff.cl }}>{cat.label}</button>;
              })}
            </div>
            <div style={{ position:"absolute", right:0, top:0, bottom:0, width:48, background:`linear-gradient(to right,transparent,${dark?DARK_PAGE2:AUBE})`, pointerEvents:"none" }}/>
          </div>
        </div>
      )}

      <div style={{ position:"relative", zIndex:1 }}>
        {mode==="oracle"&&<OracleMode favs={favs} onToggleFav={toggleFav} dark={dark} zoomedCard={zoomedCard} setZoomedCard={setZoomedCard}/>}
        {mode==="deck"  &&<DeckMode cards={filteredCards} currentIdx={currentIdx} onPrev={()=>setCurrentIdx(i=>Math.max(0,i-1))} onNext={()=>setCurrentIdx(i=>Math.min(filteredCards.length-1,i+1))} favs={favs} onToggleFav={toggleFav} dark={dark}/>}
        {mode==="favs"  &&<FavsMode favs={favs} onToggleFav={toggleFav} dark={dark}/>}
        {mode==="aide"  &&<AideMode dark={dark}/>}
      </div>

      <div style={{ position:"relative", zIndex:1, overflow:"hidden", marginTop:16 }}>
        <div style={{ position:"absolute", inset:0, background:`linear-gradient(135deg,${NUIT},${PRUNE})` }}/>
        <div style={{ position:"absolute", inset:0, backgroundImage:`radial-gradient(circle,${GOLD}06 1px,transparent 1px)`, backgroundSize:"32px 32px" }}/>
        <div style={{ position:"absolute", top:-1, left:0, right:0, height:2, background:`linear-gradient(90deg,transparent,${GOLD}40,transparent)` }}/>
        <div style={{ position:"relative", zIndex:1, padding:"40px 24px 32px", textAlign:"center" }}>
          <div style={{ maxWidth:420, margin:"0 auto" }}>
            <div style={{ fontFamily:"'Allura',cursive", fontSize:36, color:ROSE_SAT, lineHeight:1, marginBottom:8 }}>Être Elles</div>
            <h2 style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:22, fontWeight:400, fontStyle:"italic", color:"#fff", margin:"0 0 8px", lineHeight:1.2 }}>Rejoins la <em style={{ color:PIVOINE }}>communauté</em></h2>
            <p style={{ fontFamily:"'Raleway',sans-serif", fontSize:13, fontWeight:300, color:"rgba(255,255,255,0.45)", margin:"0 auto 22px", lineHeight:1.7, maxWidth:360 }}>Outils, défis et ressources pour avancer chaque jour avec confiance.</p>
            <a href="https://www.skool.com/etre-elles-8949" target="_blank" rel="noopener noreferrer" style={{ display:"inline-block", fontFamily:"'Raleway',sans-serif", fontSize:14, fontWeight:600, padding:"13px 36px", borderRadius:50, background:PIVOINE, color:"#fff", textDecoration:"none", boxShadow:`0 4px 20px ${PIVOINE}50` }}>Rejoindre Être Elles</a>
          </div>
          <div style={{ marginTop:32, paddingTop:20, borderTop:"1px solid rgba(255,255,255,0.06)" }}>
            <div style={{ fontFamily:"'Allura',cursive", fontSize:20, color:ROSE_SAT, opacity:0.65, marginBottom:5 }}>Être Elles</div>
            <div style={{ fontFamily:"'Raleway',sans-serif", fontSize:10, fontWeight:300, color:"rgba(255,255,255,0.25)", letterSpacing:"0.06em" }}>Être Soi Consulting · Tous droits réservés</div>
          </div>
        </div>
      </div>

      {/* Modal carte agrandie — niveau racine, couvre toute la page */}
      {zoomedCard && (
        <div onClick={()=>setZoomedCard(null)} style={{ position:"fixed", top:0, left:0, width:"100vw", height:"100vh", background:`linear-gradient(160deg,${NUIT} 0%,#221040 50%,${PRUNE} 100%)`, zIndex:9999, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:24 }}>
          <div onClick={e=>e.stopPropagation()} style={{ width:"100%", maxWidth:320, display:"flex", flexDirection:"column", gap:16, alignItems:"center" }}>
            <div style={{ width:"100%", height:460, animation:"popForward .45s cubic-bezier(0.34,1.56,0.64,1)" }}>
              <AffirmCard card={zoomedCard} favs={favs} onToggleFav={toggleFav} size="big"/>
            </div>
            <button onClick={()=>setZoomedCard(null)} style={{ fontFamily:"'Raleway',sans-serif", fontSize:12, fontWeight:600, padding:"10px 36px", borderRadius:30, border:`1px solid rgba(255,255,255,0.15)`, background:"rgba(255,255,255,0.07)", color:"rgba(255,255,255,0.7)", cursor:"pointer" }}>
              Fermer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
